export interface ItemList {
  id: number;
  name: string;
}
