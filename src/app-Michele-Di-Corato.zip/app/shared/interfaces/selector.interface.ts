export interface Selector {
  id: number;
  label: string;
}
